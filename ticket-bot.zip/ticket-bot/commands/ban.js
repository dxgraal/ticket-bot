const {
  SlashCommandBuilder
} = require('@discordjs/builders');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('απαγορεύστε ένα άτομο.')
    .addUserOption(option =>
      option.setName('target')
      .setDescription('μέλος σε απαγόρευση')
      .setRequired(true))
    .addStringOption(option =>
      option.setName('λόγος')
      .setDescription('λόγο της απαγόρευσης')
      .setRequired(false)),
  async execute(interaction, client) {
    const user = client.guilds.cache.get(interaction.guildId).members.cache.get(interaction.options.getUser('target').id);
    const executer = client.guilds.cache.get(interaction.guildId).members.cache.get(interaction.user.id);

    if (!executer.permissions.has(client.discord.Permissions.FLAGS.BAN_MEMBERS)) return interaction.reply({
      content: 'You do not have the required permission to execute this command ! (`BAN_MEMBERS`)',
      ephemeral: true
    });

    if (user.roles.highest.rawPosition > executer.roles.highest.rawPosition) return interaction.reply({
      content: 'Το άτομο που θέλετε να απαγορεύσετε είναι ανώτερό σας !',
      ephemeral: true
    });

    if (!user.bannable) return interaction.reply({
      content: 'The person you want to ban is above me! So I cant ban him.',
      ephemeral: true
    });

    if (interaction.options.getString('λόγος')) {
      user.ban({
        reason: interaction.options.getString('λόγος'),
        days: 1
      });
      interaction.reply({
        content: `**${user.user.tag}** Έχει αποκλειστεί επιτυχώς !`
      });
    } else {
      user.ban({
        days: 1
      });
      interaction.reply({
        content: `**${user.user.tag}** Έχει αποκλειστεί επιτυχώς !`
      });
    };
  },
};