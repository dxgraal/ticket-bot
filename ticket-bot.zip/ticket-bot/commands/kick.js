const {
  SlashCommandBuilder
} = require('@discordjs/builders');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Διώξτε ένα άτομο.')
    .addUserOption(option =>
      option.setName('target')
      .setDescription('Μέλος για διώξιμο')
      .setRequired(true))
    .addStringOption(option =>
        option.setName('λόγος')
        .setDescription('λόγος διωξίματος')
        .setRequired(false)),
  async execute(interaction, client) {
    const user = client.guilds.cache.get(interaction.guildId).members.cache.get(interaction.options.getUser('target').id);
    const executer = client.guilds.cache.get(interaction.guildId).members.cache.get(interaction.user.id);

    if (!executer.permissions.has(client.discord.Permissions.FLAGS.KICK_MEMBERS)) return interaction.reply({
      content: 'You do not have the required permission to execute this command ! (`KICK_MEMBERS`)',
      ephemeral: true
    });

    if (user.roles.highest.rawPosition > executer.roles.highest.rawPosition) return interaction.reply({
      content: 'Το άτομο που θέλετε να διώξετε είναι ανώτερό σας !',
      ephemeral: true
    });

    if (!user.kickable) return interaction.reply({
      content: 'Το άτομο που θέλεις να διώξεις είναι από πάνω μου! Οπότε δεν μπορώ να τον διώξω.',
      ephemeral: true
    });

    if (interaction.options.getString('raison')) {
      user.kick(interaction.options.getString('raison'))
      interaction.reply({
        content: `**${user.user.tag}** Έχει διωχθεί με επιτυχία !`
      });
    } else {
      user.kick()
      interaction.reply({
        content: `**${user.user.tag}** Έχει διωχθεί με επιτυχία !`
      });
    };
  },
};