const {
  SlashCommandBuilder
} = require('@discordjs/builders');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botinfos')
    .setDescription('Credits to @dxgraal#9864 for developing this bot.'),
  async execute(interaction, client) {
    const embed = new client.discord.MessageEmbed()
      .setColor('00FF51')
      .setDescription('Developed By <:crown:918488237239046195> dxgraal#9864\n\n[<:github:901207749675851816>](https://github.com/dxgraal)  [<:YouTube:918495158318809129>](https://www.youtube.com/channel/UCDmlVpGs3s1vi7qPO5UTqvg)  [<:twitter:901207826729418752>](https://twitter.com/dxgraal1)  [<:discord:901207777765130300>](https://discord.gg/2TNk7Sg76w)')
      .setFooter(client.config.footerText, client.user.avatarURL())
      .setTimestamp();

    await interaction.reply({
      embeds: [embed]
    });
  },
};